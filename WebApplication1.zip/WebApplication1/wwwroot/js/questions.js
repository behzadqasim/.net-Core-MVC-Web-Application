﻿// creating an array and passing the number, questions, options, and answers
let questions = [
    {
        numb: 1,
        question: "What is the maximum number of cookies that can be allowed to a web site? ",
        answer: "1",
        options: [
            "1",
            "2",
            "10",
            "20"
        ]
    },
    {
        numb: 2,
        question: "The technique that allow code to make function calls to .NET applications on other processes and on other machines is?",
        answer: ".NET Threading",
        options: [
            " .NET Threading",
            " .NET Remoting",
            " .NET RMT",
            " None of the above"
        ]
    },
    {
        numb: 3,
        question: "Which of the following is the default authentication mode for IIS? ",
        answer: "Basic Authentication",
        options: [
            "Anonymous",
            "Windows",
            "Basic Authentication",
            "None"
        ]
    },
    {
        numb: 4,
        question: "What does SQL stand for?",
        answer: "Structured Query Language",
        options: [
            "Stylish Question Language",
            "Stylesheet Query Language",
            "Statement Question Language",
            "Structured Query Language"
        ]
    },
    {
        numb: 5,
        question: "What does XML stand for?",
        answer: "eXtensible Markup Language",
        options: [
            "eXtensible Markup Language",
            "eXecutable Multiple Language",
            "eXTra Multi-Program Language",
            "eXamine Multiple Language"
        ]
    },
    {
        numb: 6,
        question: "Which object can help you maintain data across users?",
        answer: "Server object",
        options: [
            "Application object",
            "Session object",
            "Response object",
            "Server object"
        ]
    },
    {
        numb: 7,
        question: " An alternative way of displaying text on web page is by using",
        answer: "asp:label",
        options: [
            "asp:label",
            "asp:listitem",
            "asp:button",
            "none"
        ]
    },
    {
        numb: 8,
        question: "The technique that allow code to make function calls to .NET applications on other processes and on other machines is?",
        answer: ".NET Threading",
        options: [
            " .NET Threading",
            " .NET Remoting",
            " .NET RMT",
            " None of the above"
        ]
    },
    {
        numb: 9,
        question: "Which of the following is the default authentication mode for IIS? ",
        answer: "Basic Authentication",
        options: [
            "Anonymous",
            "Windows",
            "Basic Authentication",
            "None"
        ]
    },
    {
        numb: 10,
        question: "Attribute must be set on a validator control for the validation to work ",
        answer: "ControlToValidate",
        options: [
            "ControlToValidate",
            "ControlToBind",
            "ValidateControl",
            "Validate"
        ]
    },

];
